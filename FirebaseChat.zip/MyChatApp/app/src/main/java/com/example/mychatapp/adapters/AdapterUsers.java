package com.example.mychatapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mychatapp.ChatActivity;
import com.example.mychatapp.R;
import com.example.mychatapp.models.ModelUser;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class AdapterUsers  extends  RecyclerView.Adapter<AdapterUsers.MyHolder>{

    Context context;
    List<ModelUser>userList;

    public AdapterUsers(Context context, List<ModelUser> userList) {
        this.context = context;
        this.userList = userList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(context).inflate(R.layout.users_row,parent,false);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, final int position) {

        final String hisUid = userList.get(position).getUid();

        String userName  = userList.get(position).getName();
        final String userEmail = userList.get(position).getEmail();

        holder.mNametv.setText(userName);
        holder.memailTv.setText(userEmail);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, ChatActivity.class);
                intent.putExtra("HisUid",hisUid);
                context.startActivity(intent);
            }
        });


        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                FirebaseDatabase.getInstance().getReference()
                        .child("Users")
                        .child(hisUid)
                        .removeValue().addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful()){
                            Toast.makeText(context, "User Removed", Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                return true;
            }
        });


    }

    @Override
    public int getItemCount() {
        return userList.size();
    }

    class  MyHolder extends RecyclerView.ViewHolder {

        TextView mNametv,memailTv;


        public MyHolder(@NonNull View itemView) {
            super(itemView);
            mNametv = itemView.findViewById(R.id.naveTv);
            memailTv=itemView.findViewById(R.id.emailTv);

        }
    }
}
