package com.example.mychatapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.mychatapp.adapters.AdapterChat;
import com.example.mychatapp.models.ModeChats;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ChatActivity extends AppCompatActivity {

    Toolbar toolbar;
    RecyclerView recyclerView;
    ImageView imageView;
    TextView nameTv,statusTv;
    EditText messageEt;
    ImageButton sendBtn;
    FirebaseAuth mAuth;
    String hisUid;
    String myUid;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ValueEventListener seenListener;
    DatabaseReference userrefforseen;
    List<ModeChats>chatsList;
    AdapterChat adapterChat;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);

       Toolbar toolbar = findViewById(R.id.toolbar);
       setSupportActionBar(toolbar);
       toolbar.setTitle("");

       nameTv = findViewById(R.id.nameeTv);
       statusTv = findViewById(R.id.statusTv);
       recyclerView = findViewById(R.id.recycler_view);
       messageEt = findViewById(R.id.messageChat);
       sendBtn = findViewById(R.id.send);
       mAuth = FirebaseAuth.getInstance();
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setStackFromEnd(true);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(linearLayoutManager);
       Intent intent = getIntent();
       hisUid = intent.getStringExtra("HisUid");

       firebaseDatabase= FirebaseDatabase.getInstance();
       databaseReference = firebaseDatabase.getReference("Users");


        Query userQuery = databaseReference.orderByChild("uid").equalTo(hisUid);
        userQuery.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot d:dataSnapshot.getChildren()){
                    String name = ""+d.child("name").getValue();
                    nameTv.setText(name);
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        sendBtn.setOnClickListener(new View.OnClickListener() {
      @Override
      public void onClick(View v) {
           String message = messageEt.getText().toString().trim();
           if(TextUtils.isEmpty(message))
           {
               Toast.makeText(ChatActivity.this, "can not sent empty message", Toast.LENGTH_SHORT).show();

           }
           else{
               sendMessage(message);
           }
      }
      });

        readMessage();
        isMessageSeen();

    }

    @Override
    protected void onPause() {

        super.onPause();
        userrefforseen.removeEventListener(seenListener);
    }

    private void isMessageSeen() {
        userrefforseen = FirebaseDatabase.getInstance().getReference("chats");
        seenListener = userrefforseen.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                for(DataSnapshot d:dataSnapshot.getChildren())
                {
                    ModeChats chats = d.getValue(ModeChats.class);
                    if(chats.getReciever().equals(myUid) && chats.getSender().equals(hisUid)
                    )
                    {
                        HashMap<String,Object>hasSeenmp = new HashMap<>();
                        hasSeenmp.put("isseen",true);
                        d.getRef().updateChildren(hasSeenmp);
                    }


                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    private void readMessage() {
        chatsList = new ArrayList<>();
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference("chats");
        ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                chatsList.clear();
                for(DataSnapshot ds:dataSnapshot.getChildren()){

                    ModeChats chats = ds.getValue(ModeChats.class);

                    if(chats.getReciever().equals(myUid) && chats.getSender().equals(hisUid)
                      ||  chats.getReciever().equals(hisUid) && chats.getSender().equals(myUid)
                    )
                    {
                        chatsList.add(chats);
                    }
                    adapterChat = new AdapterChat(ChatActivity.this,chatsList);

                    adapterChat.notifyDataSetChanged();
                    recyclerView.setAdapter(adapterChat);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void sendMessage(String message) {

        String timeStamp = String.valueOf(System.currentTimeMillis());

        DatabaseReference databaseReference     = FirebaseDatabase.getInstance().getReference();
        HashMap<String,Object>mp = new HashMap<>();
        mp.put("sender",myUid);
        mp.put("reciever",hisUid);
        mp.put("message",message);
        mp.put("timeStamp",timeStamp);
        mp.put("isSeen",false);
        databaseReference.child("chats").push().setValue(mp);
        messageEt.setText("");
    }

    private void checkForAlreadyLogin() {
        FirebaseUser user = mAuth.getCurrentUser();
        if(user !=null){
             myUid = user.getUid();
        }
        else{
            startActivity(new Intent(this,MainActivity.class));
            finish();
        }
    }

    @Override
    protected void onStart() {
        checkForAlreadyLogin();
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.logout_menu,menu);

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id= item.getItemId();
        if(id==R.id.menu_log)
        {
            mAuth.signOut();
            checkForAlreadyLogin();
        }
        return super.onOptionsItemSelected(item);
    }
}
