package com.example.mychatapp.adapters;

import android.content.Context;
import android.text.format.DateFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.mychatapp.R;
import com.example.mychatapp.models.ModeChats;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class AdapterChat extends RecyclerView.Adapter<AdapterChat.MyHolder>{


    private static final int MSG_TYPE_LEFT =0;
    private static final int MSG_TYPE_RIGHT =1;
    Context context;
    List<ModeChats>chatsList;
    String ImageUri;
    FirebaseUser fuser;

    public AdapterChat(Context context, List<ModeChats> chatsList) {
        this.context = context;
        this.chatsList = chatsList;
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        if(viewType ==MSG_TYPE_RIGHT){
            View view = LayoutInflater.from(context).inflate(R.layout.right_row_chat,parent,false);
            return new MyHolder(view);
        }
        else {
            View view = LayoutInflater.from(context).inflate(R.layout.left_row_chat,parent,false);
            return new MyHolder(view);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        String message = chatsList.get(position).getMessage();
        String timeStamp = chatsList.get(position).getTimeStamp();
        Calendar calendar = Calendar.getInstance(Locale.ENGLISH);
        calendar.setTimeInMillis(Long.parseLong(timeStamp));
        String dateTime  = DateFormat.format("dd/MM/yyyy hh:mm aa",calendar).toString();

       holder.messageTv.setText(message);
       holder.timeTv.setText(dateTime);

       if(position == chatsList.size()-1)
       {
           if(chatsList.get(position).isSeen()){
               holder.isSeenTv.setText("Seen");
           }
           else{
               holder.isSeenTv.setText("Delivered");
           }
       }
       else{
           holder.isSeenTv.setVisibility(View.GONE);
       }

    }

    @Override
    public int getItemCount() {
        return chatsList.size();
    }

    @Override
    public int getItemViewType(int position) {
        fuser = FirebaseAuth.getInstance().getCurrentUser();
        if(chatsList.get(position).getSender().equals(fuser.getUid())){
            return MSG_TYPE_RIGHT;
        }
        else{
            return MSG_TYPE_LEFT;
        }
    }

    class MyHolder  extends RecyclerView.ViewHolder {
        ImageView profileView;
        TextView messageTv,timeTv,isSeenTv;
        public MyHolder(@NonNull View itemView) {
            super(itemView);


            profileView=itemView.findViewById(R.id.profile);
            messageTv = itemView.findViewById(R.id.messageTv);
            timeTv = itemView.findViewById(R.id.timeTv);
            isSeenTv = itemView.findViewById(R.id.isSeenTv);
        }
    }
}
