package com.example.mychatapp;


import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import static android.widget.Toast.LENGTH_SHORT;


/**
 * A simple {@link Fragment} subclass.
 */
public class ProfileFragment extends Fragment {


    FirebaseAuth mAuth;
    FirebaseUser mUser;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ImageView profile_image;
    TextView tName,tEmail;
    Button updateUser;
    EditText updateName;

    public ProfileFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view =  inflater.inflate(R.layout.fragment_profile, container, false);


        mAuth=FirebaseAuth.getInstance();
        mUser = mAuth.getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        final String uId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        databaseReference = firebaseDatabase.getReference("Users");

       profile_image = view.findViewById(R.id.profile_image);

       tName  = view.findViewById(R.id.tvname);
       tEmail = view.findViewById(R.id.tvemail);
       updateUser=view.findViewById(R.id.update);
       updateName = view.findViewById(R.id.updateName);
       updateUser.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View v) {

               String newname = updateName.getText().toString().trim();
               if(!TextUtils.isEmpty(newname)) {
                   Task<Void> id = databaseReference.child(uId).child("name").setValue(newname);
               }

           }
       });

        Query query = databaseReference.orderByChild("email").equalTo(mUser.getEmail());
        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {


                for(DataSnapshot d:dataSnapshot.getChildren()){

                    String name = ""+d.child("name").getValue();
                    String email = ""+d.child("email").getValue();
                    tName.setText(name);
                    tEmail.setText(email);
                }
                try {
                   Picasso.get().load(R.drawable.ic_face).into(profile_image);
                }
                catch (Exception e)
                {
                    Picasso.get().load(R.drawable.ic_face).into(profile_image);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

        return view;
    }

}
